import { createFileRoute } from "@tanstack/react-router";
import { DashboardShell } from "@/components/safeface/DashboardShell";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [{ title: "Dashboard — SafeFace AI" }],
  }),
  component: DashboardShell,
});
