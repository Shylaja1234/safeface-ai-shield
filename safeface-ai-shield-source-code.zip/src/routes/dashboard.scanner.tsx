import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/safeface/DashboardShell";
import { Radar as RadarIcon, Search } from "lucide-react";
import { RadialBarChart, RadialBar, ResponsiveContainer, PolarAngleAxis } from "recharts";

export const Route = createFileRoute("/dashboard/scanner")({
  head: () => ({ meta: [{ title: "Risk Scanner — SafeFace AI" }] }),
  component: Scanner,
});

function Scanner() {
  const [url, setUrl] = useState("");
  const [scanned, setScanned] = useState(false);

  const scores = scanned ? {
    exposure: 72,
    identity: 48,
    deepfake: 61,
  } : { exposure: 0, identity: 0, deepfake: 0 };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setScanned(false);
    setTimeout(() => setScanned(true), 800);
  };

  return (
    <div className="space-y-8 animate-reveal">
      <PageHeader
        eyebrow="Reconnaissance Module"
        title="AI Risk Scanner"
        description="Analyze public-facing profiles and websites for exposure, identity-theft, and deepfake vulnerability signals."
      />

      <form onSubmit={submit} className="p-6 rounded-lg bg-card border border-border">
        <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-3">Target URL or profile</div>
        <div className="flex gap-3">
          <div className="flex-1 flex items-center gap-2 bg-background border border-border rounded-sm px-3">
            <Search className="size-4 text-muted-foreground" />
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://twitter.com/yourhandle"
              className="flex-1 bg-transparent py-3 text-sm focus:outline-none placeholder:text-muted-foreground/50"
            />
          </div>
          <button className="px-6 bg-primary text-primary-foreground font-bold uppercase tracking-widest text-xs rounded-sm hover:brightness-110 transition flex items-center gap-2">
            <RadarIcon className="size-4" /> Scan
          </button>
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          {["instagram.com", "x.com", "linkedin.com", "tiktok.com"].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => setUrl(`https://${d}/yourhandle`)}
              className="text-[10px] font-mono uppercase tracking-widest px-2 py-1 border border-border rounded-sm text-muted-foreground hover:border-primary/50 hover:text-primary transition"
            >
              {d}
            </button>
          ))}
        </div>
      </form>

      <div className="grid md:grid-cols-3 gap-6">
        {[
          { label: "Exposure Score", value: scores.exposure, desc: "Publicly indexed images & metadata", color: "hsl(38 92% 50%)" },
          { label: "Identity Risk", value: scores.identity, desc: "PII leakage and impersonation vectors", color: "hsl(199 89% 48%)" },
          { label: "Deepfake Vulnerability", value: scores.deepfake, desc: "Suitability of public media for training", color: "hsl(0 84% 60%)" },
        ].map((s) => (
          <div key={s.label} className="p-6 rounded-lg bg-card border border-border">
            <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-2">{s.label}</div>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <RadialBarChart innerRadius="65%" outerRadius="100%" data={[{ name: s.label, value: s.value, fill: s.color }]} startAngle={90} endAngle={-270}>
                  <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
                  <RadialBar dataKey="value" background={{ fill: "hsl(210 40% 98% / 0.05)" }} cornerRadius={4} />
                </RadialBarChart>
              </ResponsiveContainer>
              <div className="-mt-32 text-center pointer-events-none relative">
                <div className="text-4xl font-display" style={{ color: s.color }}>{s.value}</div>
                <div className="text-[9px] font-mono uppercase tracking-widest text-muted-foreground">/ 100</div>
              </div>
            </div>
            <div className="text-xs text-muted-foreground mt-4">{s.desc}</div>
          </div>
        ))}
      </div>

      {scanned && (
        <div className="p-6 rounded-lg bg-card border border-border animate-reveal">
          <div className="font-display text-2xl tracking-wide mb-4">Recommended Actions</div>
          <ul className="space-y-3 text-sm">
            {[
              "Limit public profile photo resolution to under 800px",
              "Enable two-factor authentication on linked accounts",
              "Register your primary likeness in the Face Registry",
              "Remove metadata from public uploads going forward",
            ].map((r) => (
              <li key={r} className="flex items-start gap-3">
                <div className="size-1.5 rounded-full bg-primary mt-2 shrink-0" />
                <span className="text-muted-foreground">{r}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
