import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/safeface/DashboardShell";
import { protectedAssets } from "@/lib/mock-data";
import { Shield, Plus, Lock, Eye } from "lucide-react";

export const Route = createFileRoute("/dashboard/registry")({
  head: () => ({ meta: [{ title: "Face Registry — SafeFace AI" }] }),
  component: Registry,
});

function Registry() {
  const monitoring = protectedAssets.filter((a) => a.status === "monitoring").length;
  const alerts = protectedAssets.filter((a) => a.status === "alert").length;

  return (
    <div className="space-y-8 animate-reveal">
      <PageHeader
        eyebrow="Identity Vault"
        title="Face Protection Registry"
        description="Register your facial biometrics to actively monitor the web for unauthorized likeness misuse. Your images are encrypted end-to-end."
        action={
          <button className="px-5 py-3 bg-primary text-primary-foreground font-bold uppercase tracking-widest text-xs rounded-sm hover:brightness-110 transition flex items-center gap-2">
            <Plus className="size-4" /> Register Image
          </button>
        }
      />

      <div className="flex items-center gap-3 p-4 rounded-md border border-primary/30 bg-primary/5">
        <Lock className="size-4 text-primary shrink-0" />
        <p className="text-xs text-muted-foreground">
          <span className="text-primary font-medium">Privacy notice:</span> Images are securely encrypted with AES-256-GCM and never publicly shared. Only hashed biometric vectors are used for monitoring.
        </p>
      </div>

      <div className="grid sm:grid-cols-3 gap-4">
        {[
          { label: "Monitored Images", value: protectedAssets.length, icon: Shield },
          { label: "Active Monitoring", value: monitoring, icon: Eye },
          { label: "Alerts Found", value: alerts, icon: Plus, danger: alerts > 0 },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="p-6 rounded-lg bg-card border border-border">
              <div className={`size-9 rounded-md flex items-center justify-center mb-4 ${s.danger ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary"}`}>
                <Icon className="size-4" />
              </div>
              <div className="text-3xl font-display">{s.value}</div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mt-1">{s.label}</div>
            </div>
          );
        })}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {protectedAssets.map((a) => (
          <div key={a.id} className="p-5 rounded-lg bg-card border border-border hover:border-primary/50 transition">
            <div className="aspect-square rounded-md bg-background border border-border flex items-center justify-center text-5xl mb-4 relative overflow-hidden">
              <div className="absolute inset-0 scan-grid opacity-30" />
              <div className="relative">{a.thumbnail}</div>
              <div className="absolute top-2 right-2">
                <span className={`text-[9px] font-mono uppercase tracking-widest px-2 py-0.5 rounded-sm border ${
                  a.status === "alert" ? "border-destructive text-destructive" :
                  a.status === "verified" ? "border-success text-success" :
                  "border-primary text-primary"
                }`}>{a.status}</span>
              </div>
            </div>
            <div className="text-sm font-medium">{a.label}</div>
            <div className="text-[10px] font-mono text-muted-foreground mt-1">Registered {a.registeredAt}</div>
            {a.matchesFound > 0 && (
              <div className="text-[10px] font-mono text-destructive mt-2">{a.matchesFound} matches found</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
