import { createFileRoute, Link } from "@tanstack/react-router";
import heroScan from "@/assets/hero-scan.jpg";
import { Navbar } from "@/components/safeface/Navbar";
import { landingStats } from "@/lib/mock-data";
import { ScanFace, ShieldCheck, FileText, LifeBuoy, Radar, BellRing } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SafeFace AI — Protect Yourself From Deepfakes & AI Abuse" },
      { name: "description", content: "Upload suspicious media, analyze manipulation risks, generate evidence reports, and protect your digital identity." },
      { property: "og:title", content: "SafeFace AI" },
      { property: "og:description", content: "Forensic-grade deepfake detection and identity protection." },
      { property: "og:image", content: heroScan },
    ],
  }),
  component: Landing,
});

const features = [
  { num: "01", icon: ScanFace, title: "Deepfake Detection", body: "Multi-layer frame analysis to identify GAN artifacts and synthetic manipulation patterns." },
  { num: "02", icon: ShieldCheck, title: "Identity Protection", body: "Register your facial biometrics to proactively monitor for unauthorized likeness misuse." },
  { num: "03", icon: FileText, title: "Evidence Reports", body: "Generate legally-admissible forensic audit logs with cryptographic timestamps." },
  { num: "04", icon: LifeBuoy, title: "Victim Support Hub", body: "Direct guidance for reporting abuse to social platforms and legal authorities." },
  { num: "05", icon: Radar, title: "Risk Scanner", body: "Evaluate your current public digital footprint for deepfake and identity-theft vulnerability." },
  { num: "06", icon: BellRing, title: "Threat Monitoring", body: "24/7 scanning for newly surfaced AI-generated imagery featuring your biometric profile." },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-primary/30">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 scan-grid opacity-20" />
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-reveal">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/5 mb-6">
                <span className="size-2 bg-primary rounded-full animate-pulse" />
                <span className="text-[10px] font-mono uppercase tracking-tighter text-primary">Real-time Forensic Monitoring Active</span>
              </div>
              <h1 className="text-6xl md:text-7xl lg:text-8xl font-display leading-[0.9] tracking-tight text-balance mb-6">
                PROTECT YOURSELF FROM <span className="text-primary">DEEPFAKES</span>, IDENTITY MISUSE & AI ABUSE
              </h1>
              <p className="text-lg text-muted-foreground max-w-[50ch] text-pretty mb-8 leading-relaxed">
                Upload suspicious images and videos, analyze manipulation risks with forensic precision, and protect your digital identity with our secure vault architecture.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/dashboard/detection"
                  className="px-8 py-4 bg-primary text-primary-foreground font-bold uppercase tracking-widest text-sm rounded-sm hover:brightness-110 transition-all shadow-[0_0_40px_-10px_hsl(199_89%_48%/0.7)]"
                >
                  Analyze Media
                </Link>
                <Link
                  to="/auth"
                  className="px-8 py-4 border border-border text-foreground font-bold uppercase tracking-widest text-sm rounded-sm hover:bg-foreground/5 transition-all"
                >
                  Get Started
                </Link>
              </div>
            </div>

            <div className="relative animate-reveal [animation-delay:200ms]">
              <div className="absolute -inset-4 bg-primary/10 blur-3xl rounded-full opacity-40" />
              <div className="relative aspect-square rounded-2xl overflow-hidden border border-border bg-card ring-1 ring-white/5">
                <img
                  src={heroScan}
                  alt="Biometric face scan with wireframe overlay"
                  width={1024}
                  height={1024}
                  className="w-full h-full object-cover opacity-80"
                />
                <div className="absolute inset-0 pointer-events-none overflow-hidden">
                  <div className="w-full h-1 bg-primary/40 shadow-[0_0_20px_hsl(199_89%_48%/0.8)] animate-scanline" />
                  <div className="absolute top-4 right-4 flex flex-col gap-1">
                    <div className="text-[10px] font-mono text-primary bg-background/80 px-2 py-1">SIGNAL: 98%</div>
                    <div className="text-[10px] font-mono text-primary bg-background/80 px-2 py-1">FPS: 60.00</div>
                  </div>
                  <div className="absolute bottom-4 left-4 text-[10px] font-mono text-primary bg-background/80 px-2 py-1">
                    SCAN_ID: 0x{Math.floor(Math.random()*16**8).toString(16).padStart(8,'0').toUpperCase()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section id="stats" className="border-y border-border bg-card/50 py-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { v: landingStats.totalScans, l: "Total Scans" },
              { v: landingStats.reportsGenerated, l: "Reports Generated" },
              { v: landingStats.threatsIdentified, l: "Threats Identified" },
              { v: landingStats.protectedUsers, l: "Protected Users" },
            ].map((s) => (
              <div key={s.l} className="space-y-1">
                <div className="text-3xl md:text-4xl font-display tracking-wider text-primary">{s.v}</div>
                <div className="text-[10px] font-mono uppercase text-muted-foreground">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-16">
            <h2 className="text-4xl md:text-5xl font-display tracking-wide mb-4">CRITICAL CAPABILITIES</h2>
            <div className="h-1 w-24 bg-primary" />
            <p className="text-muted-foreground mt-4 max-w-2xl">A complete defense stack against AI-generated abuse — from detection to legal evidence.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f) => {
              const Icon = f.icon;
              return (
                <div key={f.num} className="group p-8 rounded-sm bg-card border border-border hover:border-primary/50 transition-all">
                  <div className="flex items-center justify-between mb-6">
                    <div className="size-10 border border-primary/30 flex items-center justify-center text-primary font-mono text-xs">
                      {f.num}
                    </div>
                    <Icon className="size-5 text-primary/60 group-hover:text-primary transition-colors" />
                  </div>
                  <h3 className="text-xl font-display tracking-wide mb-3">{f.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.body}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Dashboard preview */}
      <section id="dashboard" className="pb-24">
        <div className="max-w-7xl mx-auto px-6">
          <div className="rounded-xl border border-border bg-card overflow-hidden shadow-2xl">
            <div className="border-b border-border p-4 bg-background/50 flex items-center justify-between">
              <div className="flex gap-1.5">
                <div className="size-2.5 rounded-full bg-border" />
                <div className="size-2.5 rounded-full bg-border" />
                <div className="size-2.5 rounded-full bg-border" />
              </div>
              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Forensic_Dashboard_v4.0.2</div>
              <div />
            </div>
            <div className="p-6 md:p-8 grid lg:grid-cols-12 gap-6">
              <div className="lg:col-span-4 space-y-6">
                <div className="p-6 rounded-lg bg-background border border-border">
                  <div className="text-[10px] font-mono uppercase text-muted-foreground mb-4">Current Risk Score</div>
                  <div className="flex items-end gap-3">
                    <div className="text-5xl font-display text-primary leading-none">12</div>
                    <div className="text-xs text-muted-foreground mb-1">/ 100 (LOW)</div>
                  </div>
                  <div className="mt-4 h-1.5 w-full bg-border rounded-full overflow-hidden">
                    <div className="h-full bg-primary" style={{ width: "12%" }} />
                  </div>
                </div>
                <div className="p-6 rounded-lg bg-background border border-border">
                  <div className="text-[10px] font-mono uppercase text-muted-foreground mb-4">Alert Center</div>
                  <div className="space-y-4">
                    <div className="border-l-2 border-primary pl-3">
                      <div className="text-xs font-bold">Scan Complete</div>
                      <div className="text-[10px] text-muted-foreground">No manipulation detected in "profile_v2.jpg"</div>
                    </div>
                    <div className="border-l-2 border-border pl-3">
                      <div className="text-xs font-bold">Registry Update</div>
                      <div className="text-[10px] text-muted-foreground">3 new images added to protected vault</div>
                    </div>
                    <div className="border-l-2 border-destructive pl-3">
                      <div className="text-xs font-bold">High Risk Detection</div>
                      <div className="text-[10px] text-muted-foreground">Scan #8821 — 84% manipulation probability</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="lg:col-span-8">
                <div className="h-full p-6 rounded-lg bg-background border border-border flex flex-col">
                  <div className="flex items-center justify-between mb-6">
                    <div className="text-[10px] font-mono uppercase text-muted-foreground">Recent Analysis Logs</div>
                    <div className="text-[10px] font-mono text-primary">EXPORT DATA</div>
                  </div>
                  <div className="flex-1 grid grid-cols-7 gap-1 items-end">
                    {[40, 65, 50, 80, 35, 90, 55].map((h, i) => (
                      <div key={i} className="flex flex-col items-center gap-2">
                        <div className="w-full bg-primary/20 border border-primary/40 rounded-sm" style={{ height: `${h}%` }}>
                          <div className="w-full bg-primary rounded-sm" style={{ height: `${h * 0.6}%` }} />
                        </div>
                        <div className="text-[9px] font-mono text-muted-foreground">D{i + 1}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <Logo />
          <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
            © 2026 SafeFace Forensic Security · All Signals Encrypted
          </div>
        </div>
      </footer>
    </div>
  );
}

function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="size-7 bg-primary rounded-sm flex items-center justify-center">
        <div className="size-3.5 border-2 border-background rotate-45" />
      </div>
      <span className="font-display text-xl tracking-wider pt-1">SafeFace AI</span>
    </div>
  );
}
