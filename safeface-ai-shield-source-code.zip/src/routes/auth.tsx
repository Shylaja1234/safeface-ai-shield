import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Logo } from "@/components/safeface/Logo";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — SafeFace AI" },
      { name: "description", content: "Access your SafeFace AI forensic dashboard." },
    ],
  }),
  component: AuthPage,
});

type Tab = "login" | "register" | "forgot";

function AuthPage() {
  const [tab, setTab] = useState<Tab>("login");
  const navigate = useNavigate();

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tab === "forgot") {
      toast.success("Reset link sent to your email (demo).");
      return;
    }
    toast.success(tab === "login" ? "Signed in (demo)" : "Account created (demo)");
    navigate({ to: "/dashboard" });
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      <div className="hidden lg:flex relative flex-1 border-r border-border overflow-hidden">
        <div className="absolute inset-0 scan-grid opacity-20" />
        <div className="relative z-10 p-12 flex flex-col justify-between w-full">
          <Logo />
          <div className="space-y-6 max-w-md">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/5">
              <span className="size-2 bg-primary rounded-full animate-pulse" />
              <span className="text-[10px] font-mono uppercase tracking-tighter text-primary">Encrypted Channel</span>
            </div>
            <h2 className="font-display text-5xl tracking-wide leading-[0.95]">
              ACCESS THE <span className="text-primary">FORENSIC</span> CONSOLE
            </h2>
            <p className="text-sm text-muted-foreground">
              Sign in to manage scans, monitor your protected biometric vault, and export evidence-grade reports.
            </p>
          </div>
          <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
            SESSION_KEY · AES-256-GCM · TLS 1.3
          </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-sm space-y-6">
          <div className="lg:hidden mb-8"><Logo /></div>
          <div>
            <div className="text-[10px] font-mono uppercase tracking-widest text-primary mb-2">
              {tab === "login" && "Authentication"}
              {tab === "register" && "Registration"}
              {tab === "forgot" && "Recovery"}
            </div>
            <h1 className="font-display text-4xl tracking-wide">
              {tab === "login" && "Sign in"}
              {tab === "register" && "Create account"}
              {tab === "forgot" && "Reset password"}
            </h1>
          </div>

          <div className="flex border border-border rounded-sm overflow-hidden text-[10px] font-mono uppercase tracking-widest">
            {(["login", "register"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`flex-1 py-2.5 transition ${tab === t ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
              >
                {t === "login" ? "Sign in" : "Register"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-4">
            {tab === "register" && (
              <Field label="Full name" type="text" placeholder="Ada Lovelace" required />
            )}
            <Field label="Email" type="email" placeholder="agent@safeface.ai" required />
            {tab !== "forgot" && (
              <Field label="Password" type="password" placeholder="••••••••" required />
            )}
            <button
              type="submit"
              className="w-full px-6 py-3 bg-primary text-primary-foreground font-bold uppercase tracking-widest text-xs rounded-sm hover:brightness-110 transition shadow-[0_0_30px_-10px_hsl(199_89%_48%/0.7)]"
            >
              {tab === "login" && "Sign in"}
              {tab === "register" && "Create account"}
              {tab === "forgot" && "Send reset link"}
            </button>
          </form>

          <div className="flex justify-between text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
            {tab === "login" ? (
              <button onClick={() => setTab("forgot")} className="hover:text-primary">Forgot password?</button>
            ) : (
              <button onClick={() => setTab("login")} className="hover:text-primary">Back to sign in</button>
            )}
            <Link to="/" className="hover:text-primary">← Home</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-2">{label}</div>
      <input
        {...props}
        className="w-full bg-card border border-border rounded-sm px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition"
      />
    </label>
  );
}
