import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/safeface/DashboardShell";
import { reports, formatTime, riskLevel } from "@/lib/mock-data";
import { Download, Share2, FileText } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/reports")({
  head: () => ({ meta: [{ title: "Reports — SafeFace AI" }] }),
  component: Reports,
});

function Reports() {
  return (
    <div className="space-y-8 animate-reveal">
      <PageHeader
        eyebrow="Evidence Vault"
        title="Forensic Reports"
        description="Court-ready PDF reports with scan results, AI findings, recommendations, and cryptographic timestamps."
      />

      <div className="grid lg:grid-cols-2 gap-6">
        {reports.map((r) => {
          const level = riskLevel(r.riskScore);
          const tone = level === "low" ? "text-success" : level === "medium" ? "text-warning" : "text-destructive";
          return (
            <div key={r.id} className="p-6 rounded-lg bg-card border border-border hover:border-primary/50 transition">
              <div className="flex items-start justify-between mb-4">
                <div className="size-10 rounded-md bg-primary/10 text-primary flex items-center justify-center">
                  <FileText className="size-4" />
                </div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{r.caseId}</span>
              </div>
              <div className="font-display text-2xl tracking-wide truncate">{r.filename}</div>
              <div className="text-[10px] font-mono text-muted-foreground mt-1">Generated {formatTime(r.generatedAt)} · {r.pages} pages</div>

              <div className="mt-6 grid grid-cols-3 gap-3 text-center">
                <div className="p-3 rounded-md bg-background border border-border">
                  <div className={`text-2xl font-display ${tone}`}>{r.riskScore}</div>
                  <div className="text-[9px] font-mono uppercase tracking-widest text-muted-foreground">Risk</div>
                </div>
                <div className="p-3 rounded-md bg-background border border-border">
                  <div className={`text-xs font-mono uppercase tracking-widest ${tone} mt-2`}>{level}</div>
                  <div className="text-[9px] font-mono uppercase tracking-widest text-muted-foreground mt-1">Level</div>
                </div>
                <div className="p-3 rounded-md bg-background border border-border">
                  <div className="text-2xl font-display text-primary">PDF</div>
                  <div className="text-[9px] font-mono uppercase tracking-widest text-muted-foreground">Format</div>
                </div>
              </div>

              <div className="mt-6 flex gap-3">
                <button
                  onClick={() => toast.success("PDF download started (demo)")}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-primary text-primary-foreground font-bold uppercase tracking-widest text-xs rounded-sm hover:brightness-110 transition"
                >
                  <Download className="size-3.5" /> Download
                </button>
                <button
                  onClick={() => toast.success("Share link copied (demo)")}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 border border-border text-foreground font-bold uppercase tracking-widest text-xs rounded-sm hover:bg-foreground/5 transition"
                >
                  <Share2 className="size-3.5" /> Share
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
