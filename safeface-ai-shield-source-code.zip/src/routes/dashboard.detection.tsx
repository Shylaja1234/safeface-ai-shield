import { createFileRoute } from "@tanstack/react-router";
import { useState, useRef, useEffect } from "react";
import { PageHeader } from "@/components/safeface/DashboardShell";
import { RiskGauge } from "@/components/safeface/RiskGauge";
import {
  Upload,
  FileVideo,
  FileImage,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import {
  analyzeFile,
  loadScans,
  clearScans,
  type DetectionResult,
} from "@/lib/api/safeface-api";

export const Route = createFileRoute("/dashboard/detection")({
  head: () => ({ meta: [{ title: "Detection — SafeFace AI" }] }),
  component: DetectionPage,
});

type Phase = "idle" | "uploading" | "analyzing" | "done" | "error";

const STATUS_META: Record<
  DetectionResult["status"],
  { label: string; tone: string }
> = {
  SAFE: { label: "Safe", tone: "border-success text-success" },
  SUSPICIOUS: { label: "Suspicious", tone: "border-warning text-warning" },
  HIGH_RISK: { label: "High Risk", tone: "border-destructive text-destructive" },
};

function ClientTime({ iso }: { iso: string }) {
  const [text, setText] = useState("");
  useEffect(() => {
    setText(
      new Date(iso).toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
    );
  }, [iso]);
  return <span suppressHydrationWarning>{text}</span>;
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function DetectionPage() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [drag, setDrag] = useState(false);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [history, setHistory] = useState<DetectionResult[]>([]);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setHistory(loadScans());
  }, []);

  // Local preview URL for videos (object URL) — images use data URL from analyzer
  useEffect(() => {
    if (file && file.type.startsWith("video/")) {
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
      return () => URL.revokeObjectURL(url);
    }
  }, [file]);

  const startScan = async (f: File) => {
    if (f.size > 100 * 1024 * 1024) {
      toast.error("File exceeds 100MB limit");
      return;
    }
    setFile(f);
    setError(null);
    setResult(null);
    setProgress(0);
    setPhase("uploading");
    setPreviewUrl(null);

    try {
      const data = await analyzeFile(f, {
        duration: 2000,
        onProgress: (pct) => {
          setProgress(pct);
          if (pct >= 100) setPhase("analyzing");
        },
      });
      setResult(data);
      if (data.previewUrl) setPreviewUrl(data.previewUrl);
      setPhase("done");
      setHistory((prev) => [data, ...prev.filter((s) => s.scanId !== data.scanId)].slice(0, 20));
      toast.success("Forensic analysis complete");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Analysis failed";
      setError(msg);
      setPhase("error");
      toast.error(msg);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDrag(false);
    const f = e.dataTransfer.files[0];
    if (f) startScan(f);
  };

  const onClearHistory = () => {
    clearScans();
    setHistory([]);
    toast.success("Scan history cleared");
  };

  const isVideo = file?.type.startsWith("video/");
  const statusMeta = result ? STATUS_META[result.status] : null;

  return (
    <div className="space-y-8 animate-reveal">
      <PageHeader
        eyebrow="Forensic Module 01"
        title="Deepfake Detection"
        description="Upload an image or video. We'll analyze frames for GAN artifacts, biometric inconsistencies, and synthetic manipulation."
      />

      <div className="grid lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3 p-6 rounded-lg bg-card border border-border">
          <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-4">
            Upload Media
          </div>
          <label
            onDragOver={(e) => {
              e.preventDefault();
              setDrag(true);
            }}
            onDragLeave={() => setDrag(false)}
            onDrop={onDrop}
            className={`relative block border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition ${
              drag ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
            }`}
          >
            <input
              ref={inputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,video/mp4,video/quicktime"
              onChange={(e) => e.target.files?.[0] && startScan(e.target.files[0])}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
            <div className="size-14 mx-auto mb-4 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center text-primary">
              <Upload className="size-6" />
            </div>
            <div className="text-foreground font-medium mb-1">
              Drop file here or click to browse
            </div>
            <div className="text-xs text-muted-foreground">
              JPG · PNG · WEBP · MP4 · MOV — up to 100MB
            </div>
          </label>

          {file && (
            <div className="mt-6 space-y-4">
              {previewUrl && (
                <div className="relative overflow-hidden rounded-md border border-border bg-background">
                  {isVideo ? (
                    <video
                      src={previewUrl}
                      controls
                      className="w-full max-h-80 object-contain bg-black"
                    />
                  ) : (
                    <div className="relative">
                      <img
                        src={previewUrl}
                        alt={file.name}
                        className="w-full max-h-80 object-contain bg-black"
                      />
                      {phase === "analyzing" && (
                        <div className="absolute inset-0 pointer-events-none">
                          <div className="absolute inset-x-0 h-px bg-primary shadow-[0_0_12px_hsl(var(--primary))] animate-scanline" />
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              <div className="flex items-center gap-3 p-4 rounded-md bg-background border border-border">
                {isVideo ? (
                  <FileVideo className="size-5 text-primary" />
                ) : (
                  <FileImage className="size-5 text-primary" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{file.name}</div>
                  <div className="text-[10px] font-mono text-muted-foreground">
                    {formatBytes(file.size)}
                  </div>
                </div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-primary">
                  {phase === "uploading" && `Uploading ${progress}%`}
                  {phase === "analyzing" && "Analyzing"}
                  {phase === "done" && "Complete"}
                  {phase === "error" && "Failed"}
                </div>
              </div>

              <div className="h-1.5 w-full bg-border rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all ${
                    phase === "error" ? "bg-destructive" : "bg-primary"
                  }`}
                  style={{ width: `${phase === "done" ? 100 : progress}%` }}
                />
              </div>

              {phase === "analyzing" && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
                  <Loader2 className="size-3 animate-spin text-primary" />
                  Running multi-layer forensic analysis…
                </div>
              )}
              {phase === "error" && error && (
                <div className="flex items-start gap-2 p-3 rounded-md border border-destructive/50 bg-destructive/5 text-xs text-destructive">
                  <XCircle className="size-4 shrink-0 mt-0.5" />
                  <div className="font-mono">{error}</div>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="lg:col-span-2 p-6 rounded-lg bg-card border border-border flex flex-col">
          <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-6">
            Analysis Result
          </div>
          {phase !== "done" || !result || !statusMeta ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center text-muted-foreground">
              <div className="size-16 rounded-full border-2 border-dashed border-border flex items-center justify-center mb-4">
                <AlertTriangle className="size-6 opacity-40" />
              </div>
              <div className="text-sm">Awaiting scan</div>
              <div className="text-[10px] font-mono uppercase tracking-widest mt-1">
                Upload a file to begin
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center text-center space-y-4">
              <RiskGauge score={result.riskScore} />
              <div
                className={`text-xs font-mono uppercase tracking-widest px-3 py-1 rounded-sm border ${statusMeta.tone}`}
              >
                {statusMeta.label}
              </div>
              <div className="text-xs text-muted-foreground">
                Confidence:{" "}
                <span className="text-primary font-mono">
                  {result.confidence.toFixed(1)}%
                </span>
              </div>
              <div className="text-[10px] font-mono text-muted-foreground">
                <ClientTime iso={result.createdAt} />
              </div>
            </div>
          )}
        </div>
      </div>

      {phase === "done" && result && (
        <div className="grid lg:grid-cols-2 gap-6 animate-reveal">
          <div className="p-6 rounded-lg bg-card border border-border">
            <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-4">
              AI Analysis Summary
            </div>
            <p className="text-sm text-foreground leading-relaxed">
              {result.status === "SAFE"
                ? "Frame-by-frame analysis detected no statistically significant manipulation artifacts. Metadata is intact and biometric vectors are internally consistent."
                : result.status === "SUSPICIOUS"
                  ? "Several inconsistencies detected. Manual review is recommended before drawing conclusions."
                  : "Multiple high-confidence indicators of synthetic manipulation detected. We strongly recommend generating an evidence report."}
            </p>
            <div className="mt-4 text-[10px] font-mono text-muted-foreground">
              Scan ID: {result.scanId}
            </div>
          </div>
          <div className="p-6 rounded-lg bg-card border border-border">
            <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-4">
              Manipulation Indicators
            </div>
            <ul className="space-y-2">
              {[
                { label: "GAN artifact scan", flagged: result.analysis.ganArtifacts },
                { label: "Face consistency", flagged: !result.analysis.faceConsistency },
                { label: "Lighting & shadow coherence", flagged: !result.analysis.lightingConsistency },
                { label: "Metadata integrity", flagged: !result.analysis.metadataIntegrity },
              ].map((item) => (
                <li key={item.label} className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{item.label}</span>
                  {item.flagged ? (
                    <span className="text-destructive font-mono text-[10px] uppercase tracking-widest">
                      Flagged
                    </span>
                  ) : (
                    <CheckCircle2 className="size-4 text-success" />
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      <div className="p-6 rounded-lg bg-card border border-border">
        <div className="flex items-center justify-between mb-4 gap-3">
          <div>
            <div className="font-display text-2xl tracking-wide">Scan History</div>
            <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mt-1">
              stored locally in your browser
            </div>
          </div>
          {history.length > 0 && (
            <button
              onClick={onClearHistory}
              className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-muted-foreground hover:text-destructive transition"
            >
              <Trash2 className="size-3" />
              Clear
            </button>
          )}
        </div>
        {history.length === 0 ? (
          <div className="text-center text-sm text-muted-foreground py-8">
            No scans yet. Upload a file above to run your first forensic analysis.
          </div>
        ) : (
          <div className="divide-y divide-border">
            {history.map((s) => {
              const meta = STATUS_META[s.status];
              return (
                <div
                  key={s.scanId}
                  className="py-3 flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {s.previewUrl ? (
                      <img
                        src={s.previewUrl}
                        alt=""
                        className="size-10 rounded-md object-cover border border-border shrink-0"
                      />
                    ) : (
                      <div className="size-10 rounded-md bg-background border border-border flex items-center justify-center shrink-0">
                        {s.fileType.startsWith("video/") ? (
                          <FileVideo className="size-4 text-muted-foreground" />
                        ) : (
                          <FileImage className="size-4 text-muted-foreground" />
                        )}
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">{s.fileName}</div>
                      <div className="text-[10px] font-mono text-muted-foreground">
                        {s.scanId.toUpperCase()} · <ClientTime iso={s.createdAt} />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 shrink-0">
                    <div className="font-mono text-sm text-primary">
                      {s.confidence.toFixed(0)}%
                    </div>
                    <span
                      className={`text-[10px] font-mono uppercase tracking-widest px-2 py-1 border rounded-sm ${meta.tone}`}
                    >
                      {meta.label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
