import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader } from "@/components/safeface/DashboardShell";
import { toast } from "sonner";

export const Route = createFileRoute("/dashboard/settings")({
  head: () => ({ meta: [{ title: "Settings — SafeFace AI" }] }),
  component: Settings,
});

function Settings() {
  const [dark, setDark] = useState(true);
  const [notifs, setNotifs] = useState({ email: true, push: true, weekly: false });

  return (
    <div className="space-y-8 animate-reveal">
      <PageHeader eyebrow="Account" title="Settings" description="Manage your profile, notifications, and security preferences." />

      <Section title="User Profile">
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Full name" defaultValue="Ada Lovelace" />
          <Field label="Email" defaultValue="ada@safeface.ai" type="email" />
          <Field label="Organization" defaultValue="Independent" />
          <Field label="Country" defaultValue="United Kingdom" />
        </div>
      </Section>

      <Section title="Notifications">
        <div className="space-y-3">
          <Toggle label="Email alerts" desc="Receive scan results and threat alerts via email" value={notifs.email} onChange={(v) => setNotifs({ ...notifs, email: v })} />
          <Toggle label="Push notifications" desc="Realtime browser notifications for critical alerts" value={notifs.push} onChange={(v) => setNotifs({ ...notifs, push: v })} />
          <Toggle label="Weekly digest" desc="A summary of monitoring activity every Monday" value={notifs.weekly} onChange={(v) => setNotifs({ ...notifs, weekly: v })} />
        </div>
      </Section>

      <Section title="Security">
        <div className="space-y-3">
          <Toggle label="Two-factor authentication" desc="Require a code from your authenticator app at sign-in" value={true} onChange={() => toast.success("2FA settings updated (demo)")} />
          <Toggle label="Session encryption" desc="AES-256-GCM for all session data" value={true} onChange={() => {}} />
        </div>
      </Section>

      <Section title="Appearance">
        <Toggle label="Dark mode" desc="Forensic obsidian interface (recommended)" value={dark} onChange={setDark} />
      </Section>

      <Section title="Account Management" tone="danger">
        <div className="flex flex-wrap gap-3">
          <button className="px-4 py-2 border border-border text-foreground font-bold uppercase tracking-widest text-xs rounded-sm hover:bg-foreground/5 transition">
            Export Data
          </button>
          <button
            onClick={() => toast.error("This action is permanent (demo)")}
            className="px-4 py-2 border border-destructive/40 text-destructive font-bold uppercase tracking-widest text-xs rounded-sm hover:bg-destructive/10 transition"
          >
            Delete Account
          </button>
        </div>
      </Section>
    </div>
  );
}

function Section({ title, children, tone }: { title: string; children: React.ReactNode; tone?: "danger" }) {
  return (
    <div className={`p-6 rounded-lg bg-card border ${tone === "danger" ? "border-destructive/30" : "border-border"}`}>
      <div className={`text-[10px] font-mono uppercase tracking-widest mb-5 ${tone === "danger" ? "text-destructive" : "text-primary"}`}>{title}</div>
      {children}
    </div>
  );
}

function Field({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-2">{label}</div>
      <input
        {...props}
        className="w-full bg-background border border-border rounded-sm px-3 py-2.5 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition"
      />
    </label>
  );
}

function Toggle({ label, desc, value, onChange }: { label: string; desc: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-start justify-between gap-4 py-2">
      <div>
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{desc}</div>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`w-11 h-6 rounded-full p-0.5 transition shrink-0 ${value ? "bg-primary" : "bg-border"}`}
      >
        <div className={`size-5 rounded-full bg-background transition ${value ? "translate-x-5" : "translate-x-0"}`} />
      </button>
    </div>
  );
}
