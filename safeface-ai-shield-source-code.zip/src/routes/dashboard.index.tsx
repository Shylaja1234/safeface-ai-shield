import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/safeface/DashboardShell";
import { RiskGauge } from "@/components/safeface/RiskGauge";
import {
  overviewStats,
  recentScans,
  alerts,
  riskDistribution,
  scanTrend,
  formatTime,
} from "@/lib/mock-data";
import { Upload, ScanLine, AlertTriangle, FileText, ArrowUpRight } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid, PieChart, Pie, Cell } from "recharts";

export const Route = createFileRoute("/dashboard/")({
  component: Overview,
});

const cards = [
  { label: "Total Uploads", value: overviewStats.totalUploads, icon: Upload, hint: "+12 this week" },
  { label: "Scans Completed", value: overviewStats.scansCompleted, icon: ScanLine, hint: "93% success" },
  { label: "Threat Alerts", value: overviewStats.threatAlerts, icon: AlertTriangle, hint: "2 unresolved", danger: true },
  { label: "Reports Generated", value: overviewStats.reportsGenerated, icon: FileText, hint: "PDFs ready" },
];

function Overview() {
  return (
    <div className="space-y-8 animate-reveal">
      <PageHeader
        eyebrow="Operational Console"
        title="Overview"
        description="A live snapshot of your detection activity, threat posture, and registered identity assets."
        action={
          <Link
            to="/dashboard/detection"
            className="px-5 py-3 bg-primary text-primary-foreground font-bold uppercase tracking-widest text-xs rounded-sm hover:brightness-110 transition"
          >
            New Scan
          </Link>
        }
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <div key={c.label} className="p-6 rounded-lg bg-card border border-border hover:border-primary/50 transition group">
              <div className="flex items-start justify-between mb-4">
                <div className={`size-9 rounded-md flex items-center justify-center ${c.danger ? "bg-destructive/10 text-destructive" : "bg-primary/10 text-primary"}`}>
                  <Icon className="size-4" />
                </div>
                <ArrowUpRight className="size-4 text-muted-foreground group-hover:text-primary transition" />
              </div>
              <div className="text-3xl font-display text-foreground">{c.value}</div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mt-1">{c.label}</div>
              <div className="text-[10px] font-mono text-primary mt-2">{c.hint}</div>
            </div>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-6 rounded-lg bg-card border border-border">
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Scan Activity</div>
              <div className="font-display text-2xl tracking-wide">Last 7 days</div>
            </div>
            <div className="flex gap-4 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
              <span className="flex items-center gap-1"><span className="size-2 bg-primary rounded-sm" /> Scans</span>
              <span className="flex items-center gap-1"><span className="size-2 bg-destructive rounded-sm" /> Threats</span>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={scanTrend}>
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(199 89% 48%)" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="hsl(199 89% 48%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 98% / 0.05)" />
                <XAxis dataKey="day" stroke="hsl(215 20% 65%)" fontSize={10} />
                <YAxis stroke="hsl(215 20% 65%)" fontSize={10} />
                <Tooltip contentStyle={{ background: "hsl(222 47% 7%)", border: "1px solid hsl(210 40% 98% / 0.1)", fontSize: 12 }} />
                <Area type="monotone" dataKey="scans" stroke="hsl(199 89% 48%)" fill="url(#g1)" strokeWidth={2} />
                <Area type="monotone" dataKey="threats" stroke="hsl(0 84% 60%)" fill="hsl(0 84% 60% / 0.1)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="p-6 rounded-lg bg-card border border-border">
          <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-6">Risk Distribution</div>
          <div className="h-48 -mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={riskDistribution} dataKey="value" innerRadius={50} outerRadius={75} paddingAngle={4}>
                  {riskDistribution.map((e) => <Cell key={e.name} fill={e.color} stroke="none" />)}
                </Pie>
                <Tooltip contentStyle={{ background: "hsl(222 47% 7%)", border: "1px solid hsl(210 40% 98% / 0.1)", fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-2">
            {riskDistribution.map((r) => (
              <div key={r.name} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-2"><span className="size-2 rounded-sm" style={{ background: r.color }} />{r.name}</span>
                <span className="font-mono text-muted-foreground">{r.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-6 rounded-lg bg-card border border-border">
          <div className="flex items-center justify-between mb-6">
            <div className="font-display text-2xl tracking-wide">Recent Scans</div>
            <Link to="/dashboard/detection" className="text-[10px] font-mono uppercase tracking-widest text-primary hover:underline">View all</Link>
          </div>
          <div className="divide-y divide-border">
            {recentScans.slice(0, 5).map((s) => {
              const tone = s.status === "high-risk" ? "text-destructive" : s.status === "suspicious" ? "text-warning" : "text-success";
              return (
                <div key={s.id} className="py-3 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="size-9 rounded-md border border-border bg-background flex items-center justify-center font-mono text-[10px] text-muted-foreground uppercase shrink-0">
                      {s.type === "video" ? "MP4" : "IMG"}
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">{s.filename}</div>
                      <div className="text-[10px] font-mono text-muted-foreground">{s.id.toUpperCase()} · {formatTime(s.createdAt)}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 shrink-0">
                    <div className="hidden sm:block text-right">
                      <div className={`text-sm font-display ${tone}`}>{s.riskScore}</div>
                      <div className="text-[9px] font-mono uppercase text-muted-foreground">risk</div>
                    </div>
                    <span className={`text-[10px] font-mono uppercase tracking-widest px-2 py-1 border rounded-sm ${tone} border-current`}>
                      {s.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="p-6 rounded-lg bg-card border border-border flex flex-col items-center">
          <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mb-4 self-start">Composite Risk</div>
          <RiskGauge score={32} />
          <div className="text-xs text-muted-foreground text-center mt-4 max-w-xs">
            Aggregate risk across all scans, registered assets, and exposure signals from the last 30 days.
          </div>
        </div>
      </div>

      <div className="p-6 rounded-lg bg-card border border-border">
        <div className="font-display text-2xl tracking-wide mb-6">Activity Timeline</div>
        <div className="space-y-4">
          {alerts.slice(0, 5).map((a) => (
            <div key={a.id} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className={`size-2.5 rounded-full ${a.severity === "critical" || a.severity === "high" ? "bg-destructive" : a.severity === "medium" ? "bg-warning" : "bg-primary"}`} />
                <div className="w-px flex-1 bg-border my-1" />
              </div>
              <div className="flex-1 pb-4">
                <div className="flex items-center gap-2">
                  <div className="text-sm font-medium">{a.title}</div>
                  <span className="text-[9px] font-mono uppercase tracking-widest text-muted-foreground">{formatTime(a.timestamp)}</span>
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">{a.description}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
