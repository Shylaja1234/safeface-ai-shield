import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/safeface/DashboardShell";
import { alerts, formatTime, type Alert } from "@/lib/mock-data";
import { Bell, BellRing, ShieldAlert, FileText, AlertOctagon } from "lucide-react";

export const Route = createFileRoute("/dashboard/alerts")({
  head: () => ({ meta: [{ title: "Alerts — SafeFace AI" }] }),
  component: Alerts,
});

const iconMap = {
  scan: Bell,
  detection: ShieldAlert,
  report: FileText,
  monitor: BellRing,
};

function Alerts() {
  const unread = alerts.filter((a) => !a.read).length;

  return (
    <div className="space-y-8 animate-reveal">
      <PageHeader
        eyebrow="Signal Intelligence"
        title="Alert Center"
        description={`${unread} unread · ${alerts.length} total events across detection, monitoring, and reporting subsystems.`}
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {(["low", "medium", "high", "critical"] as const).map((sev) => {
          const count = alerts.filter((a) => a.severity === sev).length;
          const color = sev === "critical" || sev === "high" ? "destructive" : sev === "medium" ? "warning" : "primary";
          return (
            <div key={sev} className="p-5 rounded-lg bg-card border border-border">
              <div className={`text-[10px] font-mono uppercase tracking-widest mb-2 text-${color}`}>{sev}</div>
              <div className="text-3xl font-display">{count}</div>
            </div>
          );
        })}
      </div>

      <div className="p-6 rounded-lg bg-card border border-border">
        <div className="divide-y divide-border">
          {alerts.map((a: Alert) => {
            const Icon = iconMap[a.type] ?? AlertOctagon;
            const sevColor = a.severity === "critical" || a.severity === "high"
              ? "text-destructive border-destructive bg-destructive/10"
              : a.severity === "medium"
              ? "text-warning border-warning bg-warning/10"
              : "text-primary border-primary bg-primary/10";
            return (
              <div key={a.id} className={`py-4 flex items-start gap-4 ${!a.read ? "" : "opacity-70"}`}>
                <div className={`size-10 rounded-md border flex items-center justify-center shrink-0 ${sevColor}`}>
                  <Icon className="size-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium">{a.title}</span>
                    {!a.read && <span className="size-1.5 rounded-full bg-primary" />}
                    <span className={`text-[9px] font-mono uppercase tracking-widest px-2 py-0.5 border rounded-sm ${sevColor}`}>{a.severity}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">{a.description}</div>
                  <div className="text-[10px] font-mono text-muted-foreground mt-2">{formatTime(a.timestamp)}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
