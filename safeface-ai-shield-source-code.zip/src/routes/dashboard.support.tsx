import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/safeface/DashboardShell";
import { Instagram, Facebook, Youtube, Twitter, Music2, Scale, ShieldAlert, CheckSquare } from "lucide-react";

export const Route = createFileRoute("/dashboard/support")({
  head: () => ({ meta: [{ title: "Victim Support — SafeFace AI" }] }),
  component: Support,
});

const platforms = [
  { name: "Instagram", icon: Instagram, url: "https://help.instagram.com/contact/372592039493026" },
  { name: "Facebook", icon: Facebook, url: "https://www.facebook.com/help/contact/144059062408922" },
  { name: "X (Twitter)", icon: Twitter, url: "https://help.twitter.com/forms/private_information" },
  { name: "YouTube", icon: Youtube, url: "https://support.google.com/youtube/answer/2802027" },
  { name: "TikTok", icon: Music2, url: "https://www.tiktok.com/legal/report/feedback" },
];

const checklist = [
  "Document the abuse — save URLs, screenshots, and timestamps before reporting",
  "Generate a forensic PDF report from your SafeFace dashboard",
  "Report the content to the hosting platform using their dedicated form",
  "File a police report if the content involves harassment or extortion",
  "Contact an attorney specializing in digital rights for civil remedies",
  "Notify your bank/employer if identity theft has occurred",
];

function Support() {
  return (
    <div className="space-y-8 animate-reveal">
      <PageHeader
        eyebrow="Resource Center"
        title="Victim Support Hub"
        description="Reporting guides, legal resources, and an emergency checklist for AI-generated abuse."
      />

      <div className="p-6 rounded-lg border border-destructive/40 bg-destructive/5">
        <div className="flex items-center gap-3 mb-2">
          <ShieldAlert className="size-5 text-destructive" />
          <div className="font-display text-xl tracking-wide text-destructive">Emergency Help</div>
        </div>
        <p className="text-sm text-muted-foreground">
          If you are in immediate danger, contact your local emergency services first. For intimate-image abuse in the US, call the <span className="text-primary">Cyber Civil Rights Initiative hotline: 1-844-878-2274</span>.
        </p>
      </div>

      <div>
        <div className="font-display text-2xl tracking-wide mb-4">Platform Reporting Guides</div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {platforms.map((p) => {
            const Icon = p.icon;
            return (
              <a
                key={p.name}
                href={p.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-5 rounded-lg bg-card border border-border hover:border-primary/50 transition flex items-center gap-4"
              >
                <div className="size-10 rounded-md bg-primary/10 text-primary flex items-center justify-center">
                  <Icon className="size-4" />
                </div>
                <div>
                  <div className="text-sm font-medium">{p.name}</div>
                  <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Open report form →</div>
                </div>
              </a>
            );
          })}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="p-6 rounded-lg bg-card border border-border">
          <div className="flex items-center gap-3 mb-4">
            <Scale className="size-5 text-primary" />
            <div className="font-display text-xl tracking-wide">Legal Resources</div>
          </div>
          <ul className="space-y-3 text-sm">
            {[
              { l: "Cyber Civil Rights Initiative (US)", h: "https://cybercivilrights.org" },
              { l: "Revenge Porn Helpline (UK)", h: "https://revengepornhelpline.org.uk" },
              { l: "eSafety Commissioner (AU)", h: "https://www.esafety.gov.au" },
              { l: "Internet Crime Complaint Center (IC3)", h: "https://www.ic3.gov" },
            ].map((r) => (
              <li key={r.l}>
                <a href={r.h} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition">
                  → {r.l}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className="p-6 rounded-lg bg-card border border-border">
          <div className="flex items-center gap-3 mb-4">
            <CheckSquare className="size-5 text-primary" />
            <div className="font-display text-xl tracking-wide">Digital Safety Checklist</div>
          </div>
          <ul className="space-y-3">
            {checklist.map((c, i) => (
              <li key={i} className="flex items-start gap-3 text-sm">
                <div className="size-5 rounded-sm border border-primary/40 bg-primary/10 text-primary text-[10px] font-mono flex items-center justify-center mt-0.5 shrink-0">{i + 1}</div>
                <span className="text-muted-foreground">{c}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
