export type RiskLevel = "low" | "medium" | "high" | "critical";
export type ScanStatus = "safe" | "suspicious" | "high-risk";

export interface Scan {
  id: string;
  filename: string;
  type: "image" | "video";
  status: ScanStatus;
  riskScore: number;
  confidence: number;
  createdAt: string;
  indicators: string[];
}

export interface Alert {
  id: string;
  title: string;
  description: string;
  severity: RiskLevel;
  type: "scan" | "detection" | "report" | "monitor";
  timestamp: string;
  read: boolean;
}

export interface Report {
  id: string;
  caseId: string;
  scanId: string;
  filename: string;
  riskScore: number;
  generatedAt: string;
  pages: number;
}

export interface ProtectedAsset {
  id: string;
  label: string;
  thumbnail: string;
  registeredAt: string;
  matchesFound: number;
  status: "monitoring" | "alert" | "verified";
}

export const overviewStats = {
  totalUploads: 247,
  scansCompleted: 231,
  threatAlerts: 12,
  reportsGenerated: 38,
};

export const landingStats = {
  totalScans: "1.2M+",
  reportsGenerated: "850K",
  threatsIdentified: "42K",
  protectedUsers: "200K",
};

export const recentScans: Scan[] = [
  {
    id: "scn_8821",
    filename: "interview_clip_03.mp4",
    type: "video",
    status: "high-risk",
    riskScore: 84,
    confidence: 98.4,
    createdAt: "2026-06-15T09:42:00Z",
    indicators: ["GAN signature detected", "Eye-blink frequency anomaly", "Neural smoothing artifacts"],
  },
  {
    id: "scn_8820",
    filename: "profile_v2.jpg",
    type: "image",
    status: "safe",
    riskScore: 12,
    confidence: 96.1,
    createdAt: "2026-06-15T08:10:00Z",
    indicators: ["Metadata intact", "Natural lighting consistency"],
  },
  {
    id: "scn_8819",
    filename: "press_statement.mov",
    type: "video",
    status: "suspicious",
    riskScore: 56,
    confidence: 88.7,
    createdAt: "2026-06-14T22:01:00Z",
    indicators: ["Lip-sync mismatch", "Compression inconsistency"],
  },
  {
    id: "scn_8818",
    filename: "headshot_company.png",
    type: "image",
    status: "safe",
    riskScore: 4,
    confidence: 99.2,
    createdAt: "2026-06-14T18:33:00Z",
    indicators: ["No artifacts detected"],
  },
  {
    id: "scn_8817",
    filename: "social_clip_viral.mp4",
    type: "video",
    status: "high-risk",
    riskScore: 91,
    confidence: 99.0,
    createdAt: "2026-06-14T11:15:00Z",
    indicators: ["Face-swap residue", "Audio splice detected"],
  },
];

export const alerts: Alert[] = [
  {
    id: "alt_01",
    title: "High Risk Detection",
    description: "Scan #8821 flagged 84% manipulation probability in interview_clip_03.mp4",
    severity: "high",
    type: "detection",
    timestamp: "2026-06-15T09:42:00Z",
    read: false,
  },
  {
    id: "alt_02",
    title: "Identity Monitor Alert",
    description: "Possible likeness match found on x.com — review required",
    severity: "critical",
    type: "monitor",
    timestamp: "2026-06-15T07:20:00Z",
    read: false,
  },
  {
    id: "alt_03",
    title: "Scan Completed",
    description: "profile_v2.jpg analyzed — no manipulation detected",
    severity: "low",
    type: "scan",
    timestamp: "2026-06-15T08:10:00Z",
    read: true,
  },
  {
    id: "alt_04",
    title: "Report Generated",
    description: "Forensic report PDF for case #8821 is ready to download",
    severity: "medium",
    type: "report",
    timestamp: "2026-06-15T09:50:00Z",
    read: true,
  },
  {
    id: "alt_05",
    title: "Registry Update",
    description: "3 new images added to your protected vault",
    severity: "low",
    type: "monitor",
    timestamp: "2026-06-14T14:05:00Z",
    read: true,
  },
];

export const reports: Report[] = [
  { id: "rep_01", caseId: "CASE-8821", scanId: "scn_8821", filename: "interview_clip_03.mp4", riskScore: 84, generatedAt: "2026-06-15T09:50:00Z", pages: 7 },
  { id: "rep_02", caseId: "CASE-8817", scanId: "scn_8817", filename: "social_clip_viral.mp4", riskScore: 91, generatedAt: "2026-06-14T11:30:00Z", pages: 9 },
  { id: "rep_03", caseId: "CASE-8819", scanId: "scn_8819", filename: "press_statement.mov", riskScore: 56, generatedAt: "2026-06-14T22:18:00Z", pages: 5 },
];

export const protectedAssets: ProtectedAsset[] = [
  { id: "ast_01", label: "Primary headshot", thumbnail: "🪪", registeredAt: "2026-05-01", matchesFound: 0, status: "monitoring" },
  { id: "ast_02", label: "Profile portrait", thumbnail: "👤", registeredAt: "2026-05-03", matchesFound: 2, status: "alert" },
  { id: "ast_03", label: "Conference photo", thumbnail: "🎤", registeredAt: "2026-05-12", matchesFound: 0, status: "verified" },
  { id: "ast_04", label: "Editorial portrait", thumbnail: "📸", registeredAt: "2026-05-20", matchesFound: 0, status: "monitoring" },
];

export const scanTrend = [
  { day: "Mon", scans: 24, threats: 2 },
  { day: "Tue", scans: 32, threats: 4 },
  { day: "Wed", scans: 28, threats: 1 },
  { day: "Thu", scans: 41, threats: 5 },
  { day: "Fri", scans: 38, threats: 3 },
  { day: "Sat", scans: 22, threats: 1 },
  { day: "Sun", scans: 46, threats: 6 },
];

export const riskDistribution = [
  { name: "Low", value: 168, color: "hsl(142 71% 45%)" },
  { name: "Medium", value: 51, color: "hsl(38 92% 50%)" },
  { name: "High", value: 12, color: "hsl(0 84% 60%)" },
];

export function riskLevel(score: number): RiskLevel {
  if (score < 30) return "low";
  if (score < 60) return "medium";
  if (score < 85) return "high";
  return "critical";
}

export function formatTime(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
