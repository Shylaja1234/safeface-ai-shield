// SafeFace AI — frontend-only demo detector.
//
// No backend required. Generates deterministic mock results from the file's
// name + size and persists scan history to localStorage so the portfolio
// project works as a standalone frontend.

const STORAGE_KEY = "safeface_scans";
const MAX_HISTORY = 50;

export interface DetectionAnalysis {
  ganArtifacts: boolean;
  faceConsistency: boolean;
  lightingConsistency: boolean;
  metadataIntegrity: boolean;
}

export interface DetectionResult {
  scanId: string;
  status: "SAFE" | "SUSPICIOUS" | "HIGH_RISK";
  riskScore: number;
  confidence: number;
  analysis: DetectionAnalysis;
  fileName: string;
  fileType: string;
  fileSize: number;
  previewUrl?: string; // data URL for images, undefined for videos
  createdAt: string;
}

function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

function classify(score: number): DetectionResult["status"] {
  if (score < 30) return "SAFE";
  if (score < 70) return "SUSPICIOUS";
  return "HIGH_RISK";
}

function readPreview(file: File): Promise<string | undefined> {
  if (!file.type.startsWith("image/")) return Promise.resolve(undefined);
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : undefined);
    reader.onerror = () => resolve(undefined);
    reader.readAsDataURL(file);
  });
}

function buildResult(file: File, previewUrl: string | undefined): DetectionResult {
  const seed = hashString(file.name + file.size + file.type);
  const riskScore = 5 + (seed % 90);
  const confidence = 82 + (seed % 17); // 82–98
  const status = classify(riskScore);
  return {
    scanId: `scn_${seed.toString(36).slice(0, 10)}`,
    status,
    riskScore,
    confidence,
    analysis: {
      ganArtifacts: riskScore > 60,
      faceConsistency: riskScore < 70,
      lightingConsistency: riskScore < 80,
      metadataIntegrity: riskScore < 50,
    },
    fileName: file.name,
    fileType: file.type,
    fileSize: file.size,
    previewUrl,
    createdAt: new Date().toISOString(),
  };
}

// ---------- Local persistence ----------
export function loadScans(): DetectionResult[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveScans(scans: DetectionResult[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(scans.slice(0, MAX_HISTORY)));
  } catch (err) {
    // Data URLs can blow past the quota — strip previews and try again.
    try {
      const slim = scans.map(({ previewUrl: _p, ...rest }) => rest).slice(0, MAX_HISTORY);
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(slim));
    } catch {
      console.warn("[SafeFace] could not persist scan history:", err);
    }
  }
}

export function clearScans() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(STORAGE_KEY);
}

export interface AnalyzeOptions {
  onProgress?: (percent: number) => void;
  /** Total simulated analysis duration in ms. Default 2000. */
  duration?: number;
}

/**
 * Simulate a deepfake analysis end-to-end:
 *   read preview -> "upload" progress -> 2s analysis -> result.
 * Persists the result to localStorage and returns it.
 */
export async function analyzeFile(
  file: File,
  { onProgress, duration = 2000 }: AnalyzeOptions = {},
): Promise<DetectionResult> {
  const previewUrl = await readPreview(file);

  // Simulated upload progress (~40% of duration)
  await new Promise<void>((resolve) => {
    const total = Math.max(400, Math.floor(duration * 0.4));
    const tick = 80;
    const steps = Math.max(4, Math.floor(total / tick));
    let i = 0;
    const id = setInterval(() => {
      i += 1;
      const pct = Math.min(100, Math.round((i / steps) * 100));
      onProgress?.(pct);
      if (i >= steps) {
        clearInterval(id);
        resolve();
      }
    }, tick);
  });

  // Simulated analysis pause (remaining ~60%)
  await new Promise((r) => setTimeout(r, Math.max(200, Math.floor(duration * 0.6))));

  const result = buildResult(file, previewUrl);
  const history = loadScans();
  saveScans([result, ...history.filter((s) => s.scanId !== result.scanId)]);
  return result;
}
