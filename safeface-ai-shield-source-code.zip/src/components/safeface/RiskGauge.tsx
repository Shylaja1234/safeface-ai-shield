import { riskLevel } from "@/lib/mock-data";

const colors: Record<string, string> = {
  low: "hsl(142 71% 45%)",
  medium: "hsl(38 92% 50%)",
  high: "hsl(0 84% 60%)",
  critical: "hsl(0 84% 60%)",
};

export function RiskGauge({ score, size = 160 }: { score: number; size?: number }) {
  const level = riskLevel(score);
  const color = colors[level];
  const r = size / 2 - 10;
  const c = 2 * Math.PI * r;
  const dash = (score / 100) * c;

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="hsl(210 40% 98% / 0.08)" strokeWidth="8" fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth="8"
          fill="none"
          strokeDasharray={`${dash} ${c}`}
          strokeLinecap="round"
          style={{ filter: `drop-shadow(0 0 8px ${color})`, transition: "stroke-dasharray 1s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="font-display text-5xl leading-none" style={{ color }}>{score}</div>
        <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mt-1">
          {level} risk
        </div>
      </div>
    </div>
  );
}
