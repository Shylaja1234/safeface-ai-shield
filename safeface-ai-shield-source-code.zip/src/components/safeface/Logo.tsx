import { Link } from "@tanstack/react-router";

export function Logo({ to = "/" }: { to?: string }) {
  return (
    <Link to={to} className="flex items-center gap-2 group">
      <div className="size-8 bg-primary rounded-sm flex items-center justify-center group-hover:brightness-110 transition">
        <div className="size-4 border-2 border-background rotate-45" />
      </div>
      <span className="font-display text-2xl tracking-wider pt-1 text-foreground">
        SafeFace AI
      </span>
    </Link>
  );
}
