import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { type ReactNode } from "react";
import {
  LayoutDashboard,
  ScanFace,
  ShieldCheck,
  Radar,
  Bell,
  FileText,
  LifeBuoy,
  Settings,
  LogOut,
} from "lucide-react";
import { Logo } from "./Logo";

type NavItem = { to: string; label: string; icon: typeof LayoutDashboard; exact?: boolean };
const nav: NavItem[] = [
  { to: "/dashboard", label: "Overview", icon: LayoutDashboard, exact: true },
  { to: "/dashboard/detection", label: "Detection", icon: ScanFace },
  { to: "/dashboard/registry", label: "Face Registry", icon: ShieldCheck },
  { to: "/dashboard/scanner", label: "Risk Scanner", icon: Radar },
  { to: "/dashboard/alerts", label: "Alerts", icon: Bell },
  { to: "/dashboard/reports", label: "Reports", icon: FileText },
  { to: "/dashboard/support", label: "Victim Support", icon: LifeBuoy },
  { to: "/dashboard/settings", label: "Settings", icon: Settings },
];

export function DashboardShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      {/* Sidebar */}
      <aside className="hidden lg:flex w-64 shrink-0 flex-col border-r border-border bg-sidebar sticky top-0 h-screen">
        <div className="h-16 border-b border-border px-6 flex items-center">
          <Logo />
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {nav.map((item) => {
            const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to as never}
                className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  active
                    ? "bg-primary/10 text-primary border-l-2 border-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-sidebar-accent"
                }`}
              >
                <Icon className="size-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t border-border">
          <Link
            to="/"
            className="flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
          >
            <LogOut className="size-4" />
            Sign out
          </Link>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 border-b border-border bg-background/80 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between px-6">
          <div className="lg:hidden"><Logo /></div>
          <div className="hidden lg:flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
            <span className="size-2 rounded-full bg-success animate-pulse" />
            System operational · Monitoring active
          </div>
          <div className="flex items-center gap-3">
            <Link to="/dashboard/alerts" className="relative size-9 rounded-md border border-border flex items-center justify-center hover:border-primary/50 transition">
              <Bell className="size-4" />
              <span className="absolute -top-1 -right-1 size-4 rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground flex items-center justify-center">2</span>
            </Link>
            <div className="size-9 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center font-mono text-xs text-primary">
              AX
            </div>
          </div>
        </header>
        <main className="flex-1 p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export function PageHeader({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div>
        {eyebrow && <div className="text-[10px] font-mono uppercase tracking-widest text-primary mb-2">{eyebrow}</div>}
        <h1 className="font-display text-4xl md:text-5xl tracking-wide text-foreground">{title}</h1>
        {description && <p className="text-sm text-muted-foreground mt-2 max-w-2xl">{description}</p>}
      </div>
      {action}
    </div>
  );
}
