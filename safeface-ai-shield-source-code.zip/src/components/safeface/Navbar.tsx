import { Link } from "@tanstack/react-router";
import { Logo } from "./Logo";

export function Navbar() {
  return (
    <nav className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <Logo />
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
          <a href="#features" className="hover:text-primary transition-colors">Features</a>
          <a href="#stats" className="hover:text-primary transition-colors">Intelligence</a>
          <a href="#dashboard" className="hover:text-primary transition-colors">Dashboard</a>
          <Link to="/auth" className="hover:text-primary transition-colors">Sign In</Link>
          <Link
            to="/dashboard/detection"
            className="px-4 py-2 bg-foreground text-background rounded-full text-xs font-bold uppercase tracking-widest hover:bg-primary hover:text-primary-foreground transition-all"
          >
            Analyze Media
          </Link>
        </div>
        <Link to="/auth" className="md:hidden text-sm font-medium text-primary">Sign In</Link>
      </div>
    </nav>
  );
}
