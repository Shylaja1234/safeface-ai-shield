const mongoose = require("mongoose");

module.exports = async function connectDB() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.error("[DB] MONGODB_URI is not set");
    process.exit(1);
  }
  try {
    await mongoose.connect(uri);
    console.log("[DB] MongoDB connected");
  } catch (err) {
    console.error("[DB] connection error:", err.message);
    process.exit(1);
  }
};
