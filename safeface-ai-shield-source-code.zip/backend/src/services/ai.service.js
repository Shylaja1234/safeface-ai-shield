const axios = require("axios");
const fs = require("fs");
const FormData = require("form-data");
const path = require("path");

const AI_BASE = process.env.AI_SERVICE_URL || "http://localhost:8000";

/**
 * Sends a stored file to the Python AI service for deepfake analysis.
 * The Python service accepts multipart/form-data on POST /analyze
 * and returns:
 *   { status, riskScore, confidence, analysis: {...} }
 */
async function analyzeFile(absolutePath) {
  if (!fs.existsSync(absolutePath)) {
    throw new Error(`File not found at ${absolutePath}`);
  }

  const form = new FormData();
  form.append("file", fs.createReadStream(absolutePath), {
    filename: path.basename(absolutePath),
  });

  try {
    const { data } = await axios.post(`${AI_BASE}/analyze`, form, {
      headers: form.getHeaders(),
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
      timeout: 120000,
    });
    return data;
  } catch (err) {
    // Fallback so the API still functions if the Python service is down
    console.warn("[AI] service unreachable, using fallback:", err.message);
    return fallbackAnalyze(absolutePath);
  }
}

function fallbackAnalyze(absolutePath) {
  const stat = fs.statSync(absolutePath);
  // Deterministic-ish placeholder
  const seed = (stat.size + path.basename(absolutePath).length) % 100;
  const riskScore = Math.min(95, Math.max(5, seed));
  const confidence = 80 + (seed % 20);
  const status =
    riskScore < 30 ? "SAFE" : riskScore < 70 ? "SUSPICIOUS" : "HIGH_RISK";
  return {
    status,
    riskScore,
    confidence,
    analysis: {
      ganArtifacts: riskScore > 60,
      faceConsistency: riskScore < 70,
      lightingConsistency: riskScore < 80,
      metadataIntegrity: riskScore < 50,
    },
    fallback: true,
  };
}

module.exports = { analyzeFile };
