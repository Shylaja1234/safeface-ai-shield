require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
const path = require("path");

const connectDB = require("./config/db");
const authRoutes = require("./routes/auth.routes");
const detectionRoutes = require("./routes/detection.routes");
const scanRoutes = require("./routes/scan.routes");
const dashboardRoutes = require("./routes/dashboard.routes");
const { errorHandler, notFound } = require("./middleware/error.middleware");

const app = express();
const PORT = process.env.PORT || 5000;

// Security
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(
  cors({
    origin: process.env.CORS_ORIGIN?.split(",") || "*",
    credentials: true,
  }),
);
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan(process.env.NODE_ENV === "production" ? "combined" : "dev"));

// Rate limiting
app.use(
  "/api",
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
  }),
);

// Static uploads (for previewing files; remove in prod or guard with auth)
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

// Health
app.get("/health", (_req, res) =>
  res.json({ status: "ok", service: "safeface-api", time: new Date().toISOString() }),
);

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/detection", detectionRoutes);
app.use("/api/scans", scanRoutes);
app.use("/api/dashboard", dashboardRoutes);

app.use(notFound);
app.use(errorHandler);

(async () => {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`[SafeFace API] listening on http://localhost:${PORT}`);
  });
})();
