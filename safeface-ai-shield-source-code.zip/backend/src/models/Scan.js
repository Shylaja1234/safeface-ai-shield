const mongoose = require("mongoose");

const scanSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    fileName: { type: String, required: true },
    fileType: { type: String, required: true },
    fileSize: { type: Number, required: true },
    filePath: { type: String, required: true },
    riskScore: { type: Number, required: true, min: 0, max: 100 },
    confidence: { type: Number, required: true, min: 0, max: 100 },
    status: {
      type: String,
      enum: ["SAFE", "SUSPICIOUS", "HIGH_RISK"],
      required: true,
    },
    analysis: {
      ganArtifacts: Boolean,
      faceConsistency: Boolean,
      lightingConsistency: Boolean,
      metadataIntegrity: Boolean,
    },
    rawResult: { type: mongoose.Schema.Types.Mixed },
  },
  { timestamps: true },
);

module.exports = mongoose.model("Scan", scanSchema);
