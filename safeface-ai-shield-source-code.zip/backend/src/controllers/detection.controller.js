const path = require("path");
const Scan = require("../models/Scan");
const { analyzeFile } = require("../services/ai.service");

exports.uploadAndAnalyze = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No file uploaded" });

    const absolutePath = path.resolve(req.file.path);
    const result = await analyzeFile(absolutePath);

    const scan = await Scan.create({
      userId: req.user._id,
      fileName: req.file.originalname,
      fileType: req.file.mimetype,
      fileSize: req.file.size,
      filePath: req.file.path,
      riskScore: result.riskScore,
      confidence: result.confidence,
      status: result.status,
      analysis: result.analysis || {},
      rawResult: result,
    });

    res.status(201).json({
      scanId: scan._id,
      status: scan.status,
      riskScore: scan.riskScore,
      confidence: scan.confidence,
      analysis: scan.analysis,
      fileName: scan.fileName,
      fileType: scan.fileType,
      fileSize: scan.fileSize,
      createdAt: scan.createdAt,
    });
  } catch (err) {
    next(err);
  }
};
