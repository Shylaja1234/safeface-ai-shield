const Scan = require("../models/Scan");

exports.stats = async (req, res, next) => {
  try {
    const userId = req.user._id;
    const [total, safe, suspicious, highRisk, recent] = await Promise.all([
      Scan.countDocuments({ userId }),
      Scan.countDocuments({ userId, status: "SAFE" }),
      Scan.countDocuments({ userId, status: "SUSPICIOUS" }),
      Scan.countDocuments({ userId, status: "HIGH_RISK" }),
      Scan.find({ userId }).sort({ createdAt: -1 }).limit(5),
    ]);
    res.json({
      totalScans: total,
      safe,
      suspicious,
      highRisk,
      recentScans: recent,
    });
  } catch (err) {
    next(err);
  }
};
