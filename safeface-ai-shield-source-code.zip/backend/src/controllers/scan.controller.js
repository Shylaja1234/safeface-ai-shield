const Scan = require("../models/Scan");

exports.listScans = async (req, res, next) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 25, 100);
    const scans = await Scan.find({ userId: req.user._id })
      .sort({ createdAt: -1 })
      .limit(limit);
    res.json({ scans });
  } catch (err) {
    next(err);
  }
};

exports.getScan = async (req, res, next) => {
  try {
    const scan = await Scan.findOne({ _id: req.params.id, userId: req.user._id });
    if (!scan) return res.status(404).json({ message: "Scan not found" });
    res.json({ scan });
  } catch (err) {
    next(err);
  }
};
