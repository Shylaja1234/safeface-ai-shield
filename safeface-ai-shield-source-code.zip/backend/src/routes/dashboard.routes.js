const express = require("express");
const { protect } = require("../middleware/auth.middleware");
const ctrl = require("../controllers/dashboard.controller");

const router = express.Router();

router.get("/stats", protect, ctrl.stats);

module.exports = router;
