const express = require("express");
const upload = require("../middleware/upload.middleware");
const { protect } = require("../middleware/auth.middleware");
const ctrl = require("../controllers/detection.controller");

const router = express.Router();

router.post("/upload", protect, upload.single("file"), ctrl.uploadAndAnalyze);

module.exports = router;
