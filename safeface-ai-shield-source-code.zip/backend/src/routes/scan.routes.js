const express = require("express");
const { protect } = require("../middleware/auth.middleware");
const ctrl = require("../controllers/scan.controller");

const router = express.Router();

router.get("/", protect, ctrl.listScans);
router.get("/:id", protect, ctrl.getScan);

module.exports = router;
