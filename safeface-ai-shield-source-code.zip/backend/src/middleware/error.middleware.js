exports.notFound = (req, res, _next) => {
  res.status(404).json({ message: `Not found: ${req.originalUrl}` });
};

exports.errorHandler = (err, _req, res, _next) => {
  console.error("[ERROR]", err);
  const status = err.status || 500;
  res.status(status).json({
    message: err.message || "Internal server error",
    ...(process.env.NODE_ENV !== "production" && { stack: err.stack }),
  });
};
