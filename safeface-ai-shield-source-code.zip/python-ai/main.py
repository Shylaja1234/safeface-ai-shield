"""
SafeFace AI — Python detection microservice (FastAPI).

This is a placeholder detector that exposes a stable contract so a real
model (DeepFace, FaceForensics++, InsightFace, custom CNN, PyTorch, ...)
can be plugged in later without changing the Node API or React frontend.

Replace the body of `run_detector` with your model inference.
"""

import os
import hashlib
import tempfile
from pathlib import Path

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="SafeFace AI Detector", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

ALLOWED_EXT = {".jpg", ".jpeg", ".png", ".webp", ".mp4", ".mov"}


class AnalysisResult(BaseModel):
    status: str
    riskScore: int
    confidence: int
    analysis: dict


def _classify(score: int) -> str:
    if score < 30:
        return "SAFE"
    if score < 70:
        return "SUSPICIOUS"
    return "HIGH_RISK"


def run_detector(file_path: Path) -> AnalysisResult:
    """
    Placeholder. Produces a deterministic pseudo-score from the file's
    SHA-1 so repeated uploads return the same answer. Swap this entire
    function for real model inference.
    """
    h = hashlib.sha1(file_path.read_bytes()).hexdigest()
    score = int(h[:4], 16) % 100
    confidence = 80 + (int(h[4:6], 16) % 20)
    status = _classify(score)
    return AnalysisResult(
        status=status,
        riskScore=score,
        confidence=confidence,
        analysis={
            "ganArtifacts": score > 60,
            "faceConsistency": score < 70,
            "lightingConsistency": score < 80,
            "metadataIntegrity": score < 50,
        },
    )


@app.get("/health")
def health():
    return {"status": "ok", "service": "safeface-detector"}


@app.post("/analyze", response_model=AnalysisResult)
async def analyze(file: UploadFile = File(...)):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(status_code=400, detail=f"Unsupported file type: {ext}")

    with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp:
        content = await file.read()
        tmp.write(content)
        tmp_path = Path(tmp.name)

    try:
        return run_detector(tmp_path)
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
