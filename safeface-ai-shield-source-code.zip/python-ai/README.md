# SafeFace AI - Python Detector Service

FastAPI microservice that receives media files and returns a deepfake analysis.

## Run

```bash
cd python-ai
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

## Endpoint

`POST /analyze` (multipart/form-data, field `file`)

Response:
```json
{
  "status": "SAFE",
  "riskScore": 18,
  "confidence": 94,
  "analysis": {
    "ganArtifacts": false,
    "faceConsistency": true,
    "lightingConsistency": true,
    "metadataIntegrity": true
  }
}
```

## Plugging in a real model

Replace the body of `run_detector()` in `main.py` with inference from any of:

- DeepFace
- FaceForensics++
- InsightFace
- a custom CNN
- a PyTorch / ONNX model

The response shape must stay the same so the Node API and React frontend keep working.
