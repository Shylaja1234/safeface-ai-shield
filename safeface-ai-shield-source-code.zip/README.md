# SafeFace AI Shield

A production-grade deepfake detection and identity-risk monitoring platform. The frontend runs as a standalone portfolio demo (no backend required); a full Node.js + Python AI backend is included and can be enabled at any time.

---

## Project Overview

SafeFace AI Shield helps users:

- Detect deepfake images and videos
- Monitor identity risk scores
- Generate forensic-style scan reports
- Manage alerts, registries, and scan history

The UI ships with a "Forensic Obsidian" dark theme and a complete dashboard (Detection, Scanner, Alerts, Reports, Registry, Settings, Support).

## Features

- Drag-and-drop upload for images / video (up to 100 MB)
- Live upload progress + animated scan overlay
- Deterministic risk scoring with confidence %
- Manipulation indicators: GAN artifacts, face consistency, lighting consistency, metadata integrity
- Local scan history (browser storage) — no server required
- Optional real backend: Node/Express + MongoDB + Python FastAPI AI service
- JWT auth, rate limiting, helmet, CORS, bcrypt password hashing
- Pluggable AI detector (DeepFace / FaceForensics++ / InsightFace / custom PyTorch)

## Technology Stack

**Frontend**
- React 19 + TypeScript
- TanStack Start v1 (SSR + file-based routing)
- Vite 7
- Tailwind CSS v4 + shadcn/ui
- TanStack Query

**Backend (optional)**
- Node.js + Express
- MongoDB + Mongoose
- JWT, bcrypt, helmet, express-rate-limit, express-validator
- Multer (file uploads), pdfkit (reports)

**AI Service (optional)**
- Python 3.10+
- FastAPI + Uvicorn
- Pluggable detector (DeepFace, FaceForensics++, InsightFace, PyTorch)

## Frontend Architecture

```
src/
  routes/                # File-based routes (TanStack Start)
    __root.tsx
    index.tsx            # Landing
    auth.tsx
    dashboard.tsx        # Layout
    dashboard.index.tsx
    dashboard.detection.tsx
    dashboard.scanner.tsx
    dashboard.alerts.tsx
    dashboard.reports.tsx
    dashboard.registry.tsx
    dashboard.settings.tsx
    dashboard.support.tsx
  components/
    safeface/            # DashboardShell, Navbar, Logo, RiskGauge
    ui/                  # shadcn primitives
  lib/
    api/safeface-api.ts  # Frontend-only mock detector + localStorage history
    mock-data.ts
  styles.css             # Tailwind v4 theme tokens
```

## Backend Architecture

```
backend/
  src/
    server.js                       # Express bootstrap (helmet, cors, rate limit)
    config/db.js                    # Mongo connection
    middleware/                     # auth, upload, error handlers
    models/                         # User, Scan (Mongoose)
    controllers/                    # auth, detection, scan, dashboard
    routes/                         # /api/auth, /api/detection, /api/scans, /api/dashboard
    services/ai.service.js          # Calls Python FastAPI detector
  uploads/                          # Multer destination
python-ai/
  main.py                           # FastAPI POST /analyze
  requirements.txt
```

## Database Structure

**users**
| field | type |
|---|---|
| `_id` | ObjectId |
| `name` | string |
| `email` | string, unique |
| `password` | string (bcrypt, cost 12) |
| `createdAt` / `updatedAt` | Date |

**scans**
| field | type |
|---|---|
| `_id` | ObjectId |
| `userId` | ObjectId → users |
| `fileName`, `fileType`, `fileSize`, `filePath` | string / number |
| `riskScore` | number (0–100) |
| `confidence` | number (0–100) |
| `status` | `SAFE` \| `SUSPICIOUS` \| `HIGH_RISK` |
| `analysis` | `{ ganArtifacts, faceConsistency, lightingConsistency, metadataIntegrity }` |
| `rawResult` | Mixed |
| `createdAt` / `updatedAt` | Date |

## Installation

### 1. Frontend only (portfolio mode — recommended)

```bash
bun install         # or: npm install
bun run dev         # http://localhost:5173
```

No `.env`, no MongoDB, no Python required.

### 2. Full stack (with real backend)

```bash
# Terminal 1 — Python AI service
cd python-ai
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000

# Terminal 2 — Node API
cd backend
cp .env.example .env
npm install
npm run dev          # http://localhost:5000

# Terminal 3 — Frontend
cp .env.example .env # set VITE_API_URL=http://localhost:5000
bun run dev
```

Start a local MongoDB on `mongodb://localhost:27017` before launching the Node API.

## Environment Variables

**Frontend (`.env`)**
| var | description |
|---|---|
| `VITE_API_URL` | Base URL of the Node API (omit to stay in frontend-only demo mode) |

**Backend (`backend/.env`)**
| var | description |
|---|---|
| `PORT` | API port (default 5000) |
| `MONGODB_URI` | Mongo connection string |
| `JWT_SECRET` | Long random string |
| `JWT_EXPIRES_IN` | e.g. `7d` |
| `AI_SERVICE_URL` | Python FastAPI base URL (default `http://localhost:8000`) |
| `CORS_ORIGIN` | Comma-separated allowlist (e.g. `http://localhost:5173`) |
| `MAX_FILE_SIZE_MB` | Upload limit (default 100) |

## Build & Deployment

**Frontend**
```bash
bun run build       # outputs SSR-ready bundle for Cloudflare Workers / Node
bun run start       # serve production build
```
Deploy to any Workers-compatible host (Cloudflare, Netlify Edge) or a Node server.

**Backend**
```bash
cd backend && npm start
```
Containerize with the included structure or deploy to Render / Railway / Fly.io. Provision MongoDB Atlas and set env vars.

**Python AI service**
```bash
cd python-ai && uvicorn main:app --host 0.0.0.0 --port 8000
```
Deploy to any container host (Fly.io, Render, GCP Cloud Run). Swap `run_detector()` in `main.py` for a real model.

## Screenshots

> Add screenshots to `docs/screenshots/` and reference them here:
> - `docs/screenshots/landing.png`
> - `docs/screenshots/dashboard.png`
> - `docs/screenshots/detection.png`
> - `docs/screenshots/report.png`

## Future Enhancements

- Real model integration (FaceForensics++ / InsightFace / custom PyTorch)
- Frame-by-frame video heatmaps
- Browser-extension companion for in-page scanning
- Team workspaces + role-based access (admin / analyst / viewer)
- Webhook + Slack/Discord alert delivery
- PDF report export with embedded thumbnails (pdfkit pipeline scaffolded)
- Public REST API with API-key auth for third-party integrations

## License

MIT
